   <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; <?php echo date('Y');?></div>
                            <div>
                                <a href="https://phpgurukul.com/" target="_blank">PHPGurukul | Programming Blog</a>
    
                            </div>
                        </div>
                    </div>
                </footer>
            </div>